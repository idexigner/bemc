<div class="text-scroller">
    <div class="simple-marquee-container">
      <div class="marquee-sibling">
        <?php echo e(getSiteSetting('scroller_title')); ?>

      </div>
      <marquee width="100%" direction="left" height="100%" style="color: #ffffff; padding-top: 10px;">
        <?php echo e(getSiteSetting('scroller_text')); ?>

      </marquee>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\mims\resources\views/frontend/component/scroller.blade.php ENDPATH**/ ?>