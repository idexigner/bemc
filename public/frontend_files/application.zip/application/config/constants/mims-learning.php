<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['MiMS-Learning'] = array(
    array(
        'Title' => 'COPD: Clinical Review',
        'FolderName' => 'COPD_clinical_review',
        'FileNamePrefix' => 'COPD_clinical_review-',
        'FileExtension' => 'jpg',
        'NumberOfPage' => 8
    )
);
